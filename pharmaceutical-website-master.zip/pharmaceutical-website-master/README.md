# pharmaceutical-website

Our first attempt on github

Team members: 
1. https://github.com/Siman-07 : Syed Siman Fathima
2. https://github.com/spoorthi1-6: Spoorthi S
3. https://github.com/Sush-08: Sushma V Bhat
4. https://github.com/Sumu168: Sumuk V Shetty

![pharma](https://user-images.githubusercontent.com/113667419/197460045-e9d0f245-0bc3-417f-9470-7e6393e41d58.png)


